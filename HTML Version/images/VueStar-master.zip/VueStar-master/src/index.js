import VueStar from './component/VueStar.vue'
module.exports = VueStar
